import { Quote, PlayCircle, Sparkles } from 'lucide-react';

interface Leader {
  name: string;
  title: string;
  quote: string;
  color: string;
  watchQuery: string;
}

// Short, verified, publicly-documented quotes only — one per person.
// "Watch" links go to a YouTube search for their real recorded talks,
// since we link out to the actual speech rather than reproducing it here.
const LEADERS: Leader[] = [
  { name: 'Steve Jobs', title: 'Co-founder, Apple', quote: 'Stay hungry, stay foolish.', color: 'from-gray-700 to-gray-900', watchQuery: 'Steve Jobs Stanford Commencement Speech full' },
  { name: 'Elon Musk', title: 'Tesla, SpaceX', quote: 'Failure is an option here.', color: 'from-red-500 to-rose-600', watchQuery: 'Elon Musk best speech innovation' },
  { name: 'Jeff Bezos', title: 'Founder, Amazon', quote: 'Work hard, have fun, make history.', color: 'from-orange-500 to-amber-600', watchQuery: 'Jeff Bezos commencement speech' },
  { name: 'Albert Einstein', title: 'Physicist', quote: 'Imagination is more important than knowledge.', color: 'from-blue-500 to-indigo-600', watchQuery: 'Albert Einstein documentary interview' },
  { name: 'Nikola Tesla', title: 'Inventor, Engineer', quote: 'The scientists of today think deeply instead of clearly.', color: 'from-cyan-500 to-blue-600', watchQuery: 'Nikola Tesla documentary life story' },
  { name: 'Archimedes', title: 'Mathematician', quote: 'Give me a place to stand, and I will move the earth.', color: 'from-emerald-500 to-teal-600', watchQuery: 'Archimedes documentary life and inventions' },
  { name: 'Pythagoras', title: 'Mathematician, Philosopher', quote: 'Silence is better than unmeaning words.', color: 'from-purple-500 to-violet-600', watchQuery: 'Pythagoras documentary philosophy' },
  { name: 'Mukesh Ambani', title: 'Chairman, Reliance Industries', quote: 'Everybody has equal opportunity, and I think that is true for everything.', color: 'from-sky-500 to-blue-700', watchQuery: 'Mukesh Ambani speech interview' },
  { name: 'Richard Branson', title: 'Founder, Virgin Group', quote: "Business opportunities are like buses, there's always another one coming.", color: 'from-pink-500 to-rose-600', watchQuery: 'Richard Branson speech entrepreneurship' },
];

export function MotivationPage() {
  return (
    <div className="space-y-5">
      <div className="card bg-gradient-to-br from-blue-600 to-cyan-500 border-none text-white">
        <div className="flex items-center gap-2 mb-2">
          <Sparkles className="w-5 h-5" />
          <h3 className="font-semibold">Daily Motivation</h3>
        </div>
        <p className="text-sm text-white/90">
          Words from people who built things that didn't exist before. Tap "Watch" to see their real talks and interviews.
        </p>
      </div>

      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {LEADERS.map((leader) => (
          <div key={leader.name} className="card flex flex-col">
            <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${leader.color} text-white flex items-center justify-center mb-4 shrink-0`}>
              <Quote className="w-5 h-5" />
            </div>
            <p className="text-sm text-gray-800 dark:text-gray-100 flex-1 leading-relaxed">"{leader.quote}"</p>
            <div className="mt-4 pt-3 border-t border-gray-100 dark:border-gray-700 flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-gray-900 dark:text-white">{leader.name}</p>
                <p className="text-xs text-gray-500 dark:text-gray-400">{leader.title}</p>
              </div>
              <a
                href={`https://www.youtube.com/results?search_query=${encodeURIComponent(leader.watchQuery)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline shrink-0"
              >
                <PlayCircle className="w-3.5 h-3.5" /> Watch
              </a>
            </div>
          </div>
        ))}
      </div>

      <p className="text-xs text-gray-400 dark:text-gray-500 text-center">
        Quotes are short, publicly documented statements from each person, shown for inspiration only.
      </p>
    </div>
  );
}
