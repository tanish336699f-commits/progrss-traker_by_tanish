import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Minus, Medal } from 'lucide-react';
import type { Skill, Activity } from '@/lib/types';
import { buildSkillSeries, rankSkillsByGrowth } from '@/lib/skillAnalytics';
import { formatDuration } from '@/lib/time';

const LINE_COLORS = ['#3b82f6', '#f59e0b', '#10b981', '#ec4899', '#8b5cf6', '#06b6d4', '#ef4444', '#84cc16'];

const MEDAL_COLORS = ['#f59e0b', '#9ca3af', '#b45309']; // gold, silver, bronze

interface SkillGrowthChartProps {
  skills: Skill[];
  activities: Activity[];
}

export function SkillGrowthChart({ skills, activities }: SkillGrowthChartProps) {
  if (skills.length === 0) {
    return (
      <div className="card">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-1">Skill growth &amp; ranking</h3>
        <p className="text-sm text-gray-400">Add a skill on the Skills page to see growth charts here.</p>
      </div>
    );
  }

  const series = buildSkillSeries(skills, activities);
  const rankings = rankSkillsByGrowth(skills, activities);

  return (
    <div className="space-y-4">
      <div className="card">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-1">Skill growth (last 14 days)</h3>
        <p className="text-xs text-gray-500 dark:text-gray-400 mb-4">Practice minutes per day, per skill</p>
        <div style={{ width: '100%', height: 260 }}>
          <ResponsiveContainer>
            <LineChart data={series} margin={{ top: 5, right: 12, left: -12, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="currentColor" className="text-gray-200 dark:text-gray-700" />
              <XAxis dataKey="label" tick={{ fontSize: 10 }} stroke="currentColor" className="text-gray-400" />
              <YAxis tick={{ fontSize: 10 }} stroke="currentColor" className="text-gray-400" allowDecimals={false} />
              <Tooltip
                contentStyle={{ fontSize: 12, borderRadius: 8, border: '1px solid #e5e7eb' }}
                formatter={((value: unknown) => [`${value ?? 0} min`, '']) as never}
              />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              {skills.map((skill, i) => (
                <Line
                  key={skill.id}
                  type="monotone"
                  dataKey={skill.name}
                  stroke={LINE_COLORS[i % LINE_COLORS.length]}
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 4 }}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="card">
        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">Skill ranking</h3>
        <div className="space-y-2">
          {rankings.map((r) => {
            const isTop3 = r.rank <= 3 && (r.last7 > 0 || r.prev7 > 0);
            const trendUp = (r.growthPct ?? 0) > 0;
            const trendFlat = r.growthPct === 0 || r.growthPct === null;
            return (
              <div
                key={r.name}
                className="flex items-center gap-3 py-2 px-2.5 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-900/50 transition-colors"
              >
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold shrink-0 text-white"
                  style={{ backgroundColor: isTop3 ? MEDAL_COLORS[r.rank - 1] : '#9ca3af33', color: isTop3 ? 'white' : '#9ca3af' }}
                >
                  {isTop3 ? <Medal className="w-3.5 h-3.5" /> : r.rank}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate">{r.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{formatDuration(r.last7)} this week</p>
                </div>
                <div
                  className={`flex items-center gap-1 text-xs font-semibold shrink-0 ${
                    trendFlat ? 'text-gray-400' : trendUp ? 'text-emerald-500' : 'text-red-500'
                  }`}
                >
                  {trendFlat ? <Minus className="w-3.5 h-3.5" /> : trendUp ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                  {r.growthPct === null ? '—' : `${r.growthPct > 0 ? '+' : ''}${r.growthPct}%`}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
