import { createContext, useContext, useEffect, useState, type ReactNode } from 'react';
import { db } from './db';
import type { UserAccount } from './types';
import { hashPassword, verifyPassword } from './auth';

const SESSION_KEY = 'progress-tracker-session-user-id';

interface AuthContextValue {
  user: UserAccount | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signUp: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => void;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<UserAccount | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      const storedId = localStorage.getItem(SESSION_KEY);
      if (storedId) {
        const found = await db.users.get(Number(storedId));
        if (found) {
          setUser(found);
        } else {
          localStorage.removeItem(SESSION_KEY);
        }
      }
      setLoading(false);
    })();
  }, []);

  const signIn = async (email: string, password: string) => {
    const normalized = email.trim().toLowerCase();
    const found = await db.users.where('email').equals(normalized).first();
    if (!found) return { error: 'No account found with that email.' };
    const ok = await verifyPassword(password, found.passwordHash);
    if (!ok) return { error: 'Incorrect password.' };
    setUser(found);
    if (found.id !== undefined) localStorage.setItem(SESSION_KEY, String(found.id));
    return { error: null };
  };

  const signUp = async (email: string, password: string) => {
    const normalized = email.trim().toLowerCase();
    const existing = await db.users.where('email').equals(normalized).first();
    if (existing) return { error: 'An account with that email already exists on this device.' };
    const passwordHash = await hashPassword(password);
    const id = await db.users.add({ email: normalized, passwordHash, createdAt: Date.now() });
    const created = await db.users.get(id);
    if (created) {
      setUser(created);
      localStorage.setItem(SESSION_KEY, String(id));
    }
    return { error: null };
  };

  const signOut = () => {
    setUser(null);
    localStorage.removeItem(SESSION_KEY);
  };

  return (
    <AuthContext.Provider value={{ user, loading, signIn, signUp, signOut }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
