import type { Activity, Skill } from './types';
import { toDateStr } from './time';

export interface SkillDayPoint {
  date: string;
  label: string;
  [skillName: string]: string | number;
}

export interface SkillRanking {
  name: string;
  last7: number; // seconds practiced in last 7 days
  prev7: number; // seconds practiced in the 7 days before that
  growthPct: number | null; // null when prev7 is 0 and last7 is 0 (no data)
  rank: number;
}

function last14Days(): string[] {
  const days: string[] = [];
  for (let i = 13; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    days.push(toDateStr(d));
  }
  return days;
}

/** Builds one data point per day (last 14 days) with each skill's practice minutes that day, for a multi-line chart. */
export function buildSkillSeries(skills: Skill[], activities: Activity[]): SkillDayPoint[] {
  const days = last14Days();
  const skillActs = activities.filter((a) => a.domain === 'skills');

  return days.map((date) => {
    const point: SkillDayPoint = {
      date,
      label: new Date(date + 'T00:00:00').toLocaleDateString('en-US', { day: 'numeric', month: 'short' }),
    };
    for (const skill of skills) {
      const seconds = skillActs
        .filter((a) => a.category === skill.name && a.date === date)
        .reduce((sum, a) => sum + a.duration, 0);
      point[skill.name] = Math.round((seconds / 60) * 10) / 10; // minutes, 1 decimal
    }
    return point;
  });
}

/** Ranks skills by growth: last 7 days of practice time vs the 7 days before that. */
export function rankSkillsByGrowth(skills: Skill[], activities: Activity[]): SkillRanking[] {
  const now = new Date();
  const today = toDateStr(now);

  const daysAgo = (n: number) => {
    const d = new Date();
    d.setDate(d.getDate() - n);
    return toDateStr(d);
  };

  const last7Start = daysAgo(6);
  const prev7Start = daysAgo(13);
  const prev7End = daysAgo(7);

  const skillActs = activities.filter((a) => a.domain === 'skills');

  const rankings = skills.map((skill) => {
    const acts = skillActs.filter((a) => a.category === skill.name);
    const last7 = acts.filter((a) => a.date >= last7Start && a.date <= today).reduce((s, a) => s + a.duration, 0);
    const prev7 = acts.filter((a) => a.date >= prev7Start && a.date <= prev7End).reduce((s, a) => s + a.duration, 0);

    let growthPct: number | null;
    if (prev7 === 0 && last7 === 0) {
      growthPct = null;
    } else if (prev7 === 0) {
      growthPct = 100;
    } else {
      growthPct = Math.round(((last7 - prev7) / prev7) * 100);
    }

    return { name: skill.name, last7, prev7, growthPct, rank: 0 };
  });

  // Sort: skills with activity first (by growth desc, then by last7 desc), no-data skills last.
  rankings.sort((a, b) => {
    const aActive = a.last7 > 0 || a.prev7 > 0;
    const bActive = b.last7 > 0 || b.prev7 > 0;
    if (aActive !== bActive) return aActive ? -1 : 1;
    if ((b.growthPct ?? -Infinity) !== (a.growthPct ?? -Infinity)) {
      return (b.growthPct ?? -Infinity) - (a.growthPct ?? -Infinity);
    }
    return b.last7 - a.last7;
  });

  rankings.forEach((r, i) => { r.rank = i + 1; });
  return rankings;
}
