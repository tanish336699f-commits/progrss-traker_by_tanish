// On-device auth helpers. Accounts are stored locally in the browser's own
// database (Dexie/IndexedDB) — nothing is sent to a server. Passwords are
// never stored in plain text: each one is salted and hashed with SHA-256
// using the browser's built-in Web Crypto API.

function toHex(buffer: ArrayBuffer | Uint8Array): string {
  const bytes = buffer instanceof Uint8Array ? buffer : new Uint8Array(buffer);
  return Array.from(bytes).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function sha256Hex(input: string): Promise<string> {
  const data = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return toHex(digest);
}

function randomSaltHex(): string {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);
  return toHex(arr);
}

/** Hashes a new password with a fresh random salt. Returns "salt:hash". */
export async function hashPassword(password: string): Promise<string> {
  const salt = randomSaltHex();
  const hash = await sha256Hex(salt + password);
  return `${salt}:${hash}`;
}

/** Checks a password attempt against a stored "salt:hash" value. */
export async function verifyPassword(password: string, stored: string): Promise<boolean> {
  const [salt, hash] = stored.split(':');
  if (!salt || !hash) return false;
  const attempt = await sha256Hex(salt + password);
  return attempt === hash;
}
